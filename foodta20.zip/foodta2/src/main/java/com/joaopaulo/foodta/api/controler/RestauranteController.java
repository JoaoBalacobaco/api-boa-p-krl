package com.joaopaulo.foodta.api.controler;

import com.joaopaulo.foodta.damain.model.FormaPagamento;
import com.joaopaulo.foodta.damain.model.Restaurante;
import com.joaopaulo.foodta.damain.repository.RestauranteRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/restaurantes")
public class RestauranteController {
    @Autowired
    private RestauranteRepository restauranteRepository;

    @GetMapping
    public List<Restaurante> listar() {
        return restauranteRepository.listar();
    }

    @GetMapping("/{restauranteId}")
    public ResponseEntity<Restaurante> buscar(@PathVariable Long RestauranteId) {
        Restaurante restaurante = restauranteRepository.buscar(RestauranteId);
        if (restaurante != null) {
            return ResponseEntity.ok(restaurante);
        }
        return ResponseEntity.notFound().build();
    }

    @PostMapping
    @ResponseStatus
    public Restaurante adicionar(@RequestBody Restaurante restaurante) {
        return restauranteRepository.salvar(restaurante);
    }
}