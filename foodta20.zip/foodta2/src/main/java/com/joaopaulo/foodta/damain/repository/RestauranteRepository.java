package com.joaopaulo.foodta.damain.repository;

import com.joaopaulo.foodta.damain.model.Restaurante;

import org.springframework.stereotype.Repository;

import java.util.List;

@Repository

public interface RestauranteRepository {
    List<Restaurante> listar();
    Restaurante buscar(Long id);
    Restaurante salvar(Restaurante restaurante);
    void remover(Long id);
}
