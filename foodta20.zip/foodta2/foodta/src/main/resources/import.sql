
insert into tb_cozinha(nome_cozinha) values ('Brasileira');
insert into tb_cozinha(nome_cozinha) values ('Italiana');
insert into tb_cozinha(nome_cozinha) values ('Japonesa');

insert into tb_cidade()